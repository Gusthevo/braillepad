from typing import Optional
from pydantic import BaseModel, Field

class PreferenciaResponse(BaseModel):
    professor_id: str
    tema: str = Field(default="SISTEMA", example="SISTEMA", description="CLARO, ESCURO, SISTEMA")
    escala_fonte: float = Field(default=1.00, ge=0.80, le=2.00, example=1.00)
    alto_contraste: bool = Field(default=False, example=False)
    som_ativo: bool = Field(default=True, example=True)
    vibracao_ativa: bool = Field(default=True, example=True)
    volume_som: int = Field(default=80, ge=0, le=100, example=80)
    modo_execucao_padrao: str = Field(default="MANUAL", example="MANUAL", description="MANUAL ou SIMULACAO")


class PreferenciaUpdateRequest(BaseModel):
    tema: Optional[str] = None
    escala_fonte: Optional[float] = None
    alto_contraste: Optional[bool] = None
    som_ativo: Optional[bool] = None
    vibracao_ativa: Optional[bool] = None
    volume_som: Optional[int] = None
    modo_execucao_padrao: Optional[str] = None
