# Pydantic schemas and DTOs
