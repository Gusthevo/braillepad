import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'api_service.dart';
import 'auth_service.dart';

class PreferenciasService {
  static Map<String, String> get _headers => {
        'Content-Type': 'application/json',
        if (AuthService.token != null) 'Authorization': 'Bearer ${AuthService.token}',
      };

  // 1. Obter Preferências Reais do Professor (PostgreSQL)
  static Future<Map<String, dynamic>?> getPreferencias() async {
    try {
      final response = await http
          .get(Uri.parse('${ApiService.baseUrl}/api/auth/preferencias'), headers: _headers)
          .timeout(const Duration(seconds: 5));

      if (response.statusCode == 200) {
        return jsonDecode(response.body) as Map<String, dynamic>;
      }
      return null;
    } catch (e) {
      debugPrint('Error fetching preferencias: $e');
      return null;
    }
  }

  // 2. Atualizar Preferências do Professor no PostgreSQL
  static Future<bool> updatePreferencias({
    String? tema,
    double? escalaFonte,
    bool? altoContraste,
    bool? somAtivo,
    bool? vibracaoAtiva,
    int? volumeSom,
    String? modoExecucaoPadrao,
  }) async {
    try {
      final response = await http
          .patch(
            Uri.parse('${ApiService.baseUrl}/api/auth/preferencias'),
            headers: _headers,
            body: jsonEncode({
              if (tema != null) 'tema': tema,
              if (escalaFonte != null) 'escala_fonte': escalaFonte,
              if (altoContraste != null) 'alto_contraste': altoContraste,
              if (somAtivo != null) 'som_ativo': somAtivo,
              if (vibracaoAtiva != null) 'vibracao_ativa': vibracaoAtiva,
              if (volumeSom != null) 'volume_som': volumeSom,
              if (modoExecucaoPadrao != null) 'modo_execucao_padrao': modoExecucaoPadrao,
            }),
          )
          .timeout(const Duration(seconds: 5));

      return response.statusCode == 200;
    } catch (e) {
      debugPrint('Error updating preferencias: $e');
      return false;
    }
  }
}
